import { createClient } from "@supabase/supabase-js";

const supabaseUrl = "https://yobuntpfrezdwzltaalo.supabase.co";

const supabaseKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

if (!supabaseKey) {
  throw new Error("Missing Supabase publishable key.");
}

export const supabase = createClient(supabaseUrl, supabaseKey);